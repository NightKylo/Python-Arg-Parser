# __main__.py

from . import __version__

print(f"You are running arg_parser version {__version__}.\nThis tool is supposed to be integrated in a project not to be directly called.")
